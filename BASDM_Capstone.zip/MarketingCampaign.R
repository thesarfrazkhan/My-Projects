setwd("C:/Users/User/Downloads/BASDMCapstone")
####1.Import the input file. Check if the variable with date values has been imported appropriately

df = read.csv("marketing_campaign.csv", sep ='\t', header = T)

View(df)
str(df)

nrow(df)

ncol(df)
dim(df)

head(df)

df$Dt_Customer= as.Date(df$Dt_Customer,format='%d-%m-%Y')
library('lubridate')
ymd(df$Dt_Customer)

###2.	Find the variables with missing values. If the proportion of missing values is less
##than 5%, then delete the rows

summary(df)


sum(is.na(df))



sapply(df,function(x){sum(is.na(x))})

24/nrow(df)

df = na.omit(df)
sum(is.na(df))

####3.	Calculate the newest and oldest customer's enrolment date in the records

recent = max(df$Dt_Customer)


oldest = min(df$Dt_Customer)


######4.	Create a feature "Customer_For" of the number of days the customers started
##to shop in the store relative to the last recorded date

df$Customer_For = as.numeric(recent- df$Dt_Customer)

head(df$Customer_For)

####5.	Find the "Age" of customers by the "Year_Birth" indicating the birth year

##Age = present year - year of birth

df$age = year(Sys.Date())-df$Year_Birth

head(df$age)

####6.	Create a feature "Spent" indicating the total amount spent by the customer
##in various categories over two years

df_mnt = df[,grep('Mnt',colnames(df))]

df$spent = apply(df_mnt,MARGIN=1,FUN=sum)


####7.	Create another feature "Living_With" out of "Marital_Status" to extract the living
##situation of couples. Consider a value ‘Partner’ for the variable "Living_With" for 
##the instances where "Marital_Status" is either “Married” or “Together”. Rest all can be
##taken as ‘Alone’

table(df$Marital_Status)

df$Living_With = ifelse(df$Marital_Status %in% c('Married','Together'),'Partner','Alone')


####8.	Create a feature "Children" to indicate the total number of children in a
##household that is, kids and teenagers


df$Children = df$Kidhome+df$Teenhome


#####9.	To get further clarity on a household, create a feature indicating "Family_Size"

df$Family_size = ifelse(df$Living_With=='Alone',1,2)+df$Children

#####10.	Create a feature "Is_Parent" to indicate the parenthood status

df$Is_Parent <- ifelse(df$Children>0,1,0)

######11.	Keep only two categories in the field – ‘Education’ – Undergraduate, Graduate

table(df$Education)


df$Education =  ifelse(df$Education %in% c("2n Cycle","Basic"),"Undergraduate","Graduate")

table(df$Education)


#####12.	For clarity, change the name of the variables (remove mnt from the variables)

df_2 = df[,grep('Mnt',colnames(df))]

View(df_2)

colnames(df_2) =  sub('Mnt','',colnames(df_2))

View(df_2)


####13. Drop the redundant columns: "Marital_Status", "Dt_Customer", "Z_CostContact",
###"Z_Revenue", "Year_Birth", and "ID"

df_new = df[,-which(colnames(df) %in% c("Marital_Status","Dt_Customer","Z_CostContact","Z_Revenue","Year_Birth","ID"))]

####Create box plots and histograms for age and income. 
##Identify the outliers and delete rows with outliers

boxplot(df$age,main="boxplot for age")



boxplot(df$Income,main="boxplot for income")



find_interval = function(x){
  q1 = quantile(x,0.25)
  q3 = quantile(x,0.75)
  iqr = q3-q1
  low_limit = q1-(1.5*iqr)
  up_limit = q3+(1.5*iqr)
  return (c(low_limit,up_limit))}

find_lim_age = find_interval(df$age)

find_lim_age

find_lim_income = find_interval(df$Income)

find_lim_income



df_new = df_new[(df_new$age >find_lim_age[1]) & (df_new$age <find_lim_age[2]),]

dim(df_new)


df_new = df_new[(df_new$Income >find_lim_income[1]) & (df_new$Income <find_lim_income[2]),]

hist(df_new$age,main='histogram for age',breaks=20)


hist(df_new$Income,main='histogram for income',breaks=30)

##### Find out the correlation between variables. Create a heatmap to visualize the
##correlation plot


str(df_new)

drop_column = sapply(df_new,class) =='character'

df_num = df_new[- drop_column]

head(df_num)

df_num$Living_With <- NULL

# correlation matrix

cor_mat = cor(df_num)

install.packages("corrplot")
library(corrplot)

corrplot(cor_mat)


#######Now you should prepare the data for cluster analysis and Categorical variables
#####must be incorporated in clustering. Perform necessary encoding techniques to 
#####transform the categorical variables


names(df_new[sapply(df_new,class)=='character'])
df_new$Education = as.numeric(factor(df_new$Education))

df_new$Living_With = as.numeric(factor(df_new$Living_With))

str(df_new)


######Find the appropriate number of clusters using the elbow method

df_new1 = scale(df_new)


clus_result = kmeans(df_new1,centers=3,iter.max=10)


table(clus_result$cluster)

clus_result$tot.withinss

clus_result$withinss

withinss = sapply(1:15,function(x){kmeans(df_new1,centers=x,iter.max = 10)$tot.withinss})

withinss

plot(1:15,withinss,main='total within ss for each # clusters',type='o')

# requisite no of clusters =4 


clus_final =  kmeans(df_new1,centers=4,iter.max=10)

clus_final$cluster

table(clus_final$cluster)


#### After a cluster analysis is performed, it is important for the business to
###define the clusters. Perform cluster profiling, describe each cluster in detail, and
##use appropriate visualizations to support your views

install.packages('factoextra')


library('factoextra')


df_new$cluster = clus_final$cluster

fviz_cluster(clus_final,data=df_new1,geom="point")

# incomes across the clusters

library(dplyr)

df_new %>% group_by(cluster) %>% summarise(avg_income=mean(Income),avg_age=mean(age),
                                           avg_spent=mean(spent))

