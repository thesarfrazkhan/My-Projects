setwd("C:/Users/User/Downloads/Predictive Analytics")

#####Import the dataset in R and check its dimensions and characteristics

heart = read_excel("1666257828_heart.xlsx")

dim(heart)
str(heart)






######Check the class of different variables in the dataset

class(heart$cycling)
class(heart$smoking)
class(heart$heart_diseases)


#####Summarize the data and display the head and tail of the data

summary(heart)

head(heart)
tail(heart)



#######Check the normality of dependent variables and plot the relationship between the dependent and independent variables and summarize your observation
shapiro.test(heart$heart_diseases)

N_heart_disease  = rnorm(498, mean = mean(heart$heart_diseases))


plot(density(heart$heart_diseases), col= "green", lwd = 4, ylim= c(0,0.4))
lines(density(N_heart_disease), col= "red", lwd = 4)


plot(heart$heart_diseases, heart$cycling, type = "p")
plot(heart$heart_diseases, heart$smoking, type = "p")



#######Create and run the regression model for the dataset and summarize the observation

index = sample(1: nrow(heart), as.integer(0.8*nrow(heart)))

train = heart[index,]
test =  heart[-index,]

dim(train)

model = lm(heart_diseases~cycling+smoking, data = train)
summary(model)

######Store the output of the regression model and print its coefficients

Output = summary(model)


Output$coefficients





#######Print the estimate, Std. Error, t-value, and p-value for the independent variables (i.e., cycling and smoking)

Output$coefficients["cycling",]
Output$coefficients["smoking",]





######Display residual standard error, r-squared, adjusted r-squared, f-statistic, and p-value from the output

Output$sigma
Output$r.squared
Output$adj.r.squared
Output





######Compute the confidence intervals

confint(model, "cycling")
confint(model, "smoking")

######Create the diagnostic plots and point out your observation for it

par(mfrow=c(2,2)) 


# Residuals vs Fitted
plot(model, which=1)

# Normal Q-Q plot
plot(model, which=2)

# Scale-Location vs Fitted
plot(model, which=3)

# Cook's distance
plot(model, which=4)



######Check autocorrelation and heteroscedasticity using an appropriate statistical test
library(lmtest)


dwtest(model)

bptest(model)
