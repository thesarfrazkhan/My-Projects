setwd("C:/Users/User/Downloads/statistical analysis")
#1. Import the data to check its class and structure and display the head and tail of the data
data = read_excel("1662617767_data.xlsx")
class(data)
str(data)
head(data)
tail(data)

#2. Calculate the:
#a.	Difference in the means of the pre and post variables
mean(data$Pre)-mean(data$Post)
abs(mean(data$Pre)-mean(data$Post))

#b.	Values that divide the pre and post variable data into equal halves
median(data$Pre)

median((data$Post))

#c.	Mode for the pre variable

install.packages("statip")
library(statip)
head(mfv(data$Pre),5)

#d.	First and third quantile for the pre and post variables
Q1pre = quantile(data$Pre, 0.25)
Q1pre  
Q3pre = quantile(data$Pre, 0.75)
Q3pre

Q1post = quantile(data$Post, 0.25)
Q1post
Q3post = quantile(data$Post, 0.75)
Q3post

#e.	Range of the pre and post variables

range(data$Pre)
range(data$Post)

#f.	Variance and standard deviation for the pre and post variables

var(data$Pre)
var(data$Post)

sd(data$Pre)
sd(data$Post)

#g.	Coefficient of variation and mean absolute deviation for the pre and post variables

Coefficient_of_variation_Pre = sd(data$Pre)/mean(data$Pre)
Coefficient_of_variation_Pre

Coefficient_of_variation_Post = sd(data$Post)/mean(data$Post)
Coefficient_of_variation_Post


mad(data$Pre)
mad(data$Post)

#h.	Interquartile range of the pre and post variables

IQR(data$Pre)
IQR(data$Post)

Q3pre-Q1pre
Q3post-Q1post

#3.	Measure the skewness for pre and post variables and apply the Agostino test to check the skewness

install.packages("tseries")
install.packages("moments")
library(tseries)
library(moments)

Norm= rnorm(10000)

skewness(Norm)
skewness(data$Pre)
skewness(data$Post)

agostino.test(Norm)
agostino.test(data$Pre)
agostino.test(data$Post) 

#4.	Identify the nature of distribution through kurtosis for both pre and post variables and confirm the result through the Anscombe test

kurtosis(Norm)
kurtosis(data$Pre)
kurtosis(data$Post)

anscombe.test(Norm)
anscombe.test(data$Pre)
anscombe.test(data$Post)

#5.	Plot a graph to check the skewness and peakedness in the distribution of pre and post variables

hist(Norm, probability = T)

lines(density(Norm), col = "red", lwd = 1)

hist(data$Pre, probability = T)

lines(density(data$Pre), col = "red", lwd = 1)

hist(data$Post, probability = T)

lines(density(data$Post), col = "red", lwd = 1)

#6.	Compute the frequency and relative frequency for each brand of colddrink

install.packages("tidyverse")
library(tidyverse)
library(dplyr)

Frequency_CD =  data|>count(`Cold-Drink`)

RelativeF_CD = Frequency_CD$n/sum(Frequency_CD$n)


#7.	Create a pie chart and bar chart to show the preferences of the colddrinks available and provide the necessary labels

install.packages("plotly")
library(plotly)


plot_ly(data = Frequency_CD, values = ~n, labels = ~`Cold-Drink`,
        type = "pie",
        textinfo = "label+percent",
        showlegend = T)




plot_ly(data = Frequency_CD, x = ~`Cold-Drink`, y = ~n,
        type = "bar",
        showlegend = T)




###8.	Plot a density graph on the cold-drink frequency and comment on the skewness and kurtosis


NormCD= rnorm(1000, mean = mean(Frequency_CD$n), sd=sd(Frequency_CD$n))
NormCD= as.data.frame(NormCD)

Frequency_CD = as.data.frame(Frequency_CD)

skewness(NormCD)
skewness(Frequency_CD$n)


kurtosis(NormCD)
kurtosis(Frequency_CD$n)

plot(density(Frequency_CD$n), col= "black", lwd = 3)
lines(density(NormCD$NormCD), col= "red", lwd= 3)



###9.	Convert the ‘Status’, ‘Rating’, and ‘Outlook’ variables into factor types and summarize them  


Status = as.factor(data$Status)
Rating = as.factor(data$Rating)
Outlook = as.factor(data$Outlook)


summary(Status)
summary(Rating)
summary(Outlook)

summary(c(Status, Rating, Outlook))

##10.	Calculate the difference in the average pre-training satisfaction ratings of member and 
##observer status and for the post-training member and observer status

library(tidyverse)

data|>group_by(Status)|> summarise(Avg_Pre= mean(Pre))

AvgPreData = data.frame(data|>group_by(Status)|> summarise(Avg_Pre= mean(Pre)))

diff(AvgPreData$Avg_Pre)
######

data|>group_by(Status)|> summarise(Avg_Post= mean(Post))
           
AvgPostData = data.frame(data|>group_by(Status)|> summarise(Avg_Post= mean(Post)))
diff(AvgPostData$Avg_Post)

####11.	Compute the average pre-satisfaction and post-satisfaction ratings of employees with a 
##‘Stable’ Outlook

stable_pre = data.frame(data|>group_by(Outlook)|>summarise(AvgPreSatisfaction = mean(Pre)))|>
  filter(Outlook=="Stable")

stable_post = data.frame(data|>group_by(Outlook)|>summarise(AvgPostSatisfaction = mean(Post)))|>
  filter(Outlook=="Stable")


###12.	Construct a confidence interval at a 2.5%, 5%, and 1% level of significance for the salary
#variable

sample(data$Salary, 50, replace = T)

set.seed(51)
sample(data$Salary, 50, replace = T)

Salary =sample(data$Salary, 50, replace = T)

library(distributions3)

DOF = length(Salary)-1

#5% confidence

a=0.05

t= qt(p= a/2, df= DOF, lower.tail = F)

SE = sd(Salary)/sqrt(length(Salary))

MOE = t*SE

lower= mean(Salary)-MOE
upper= mean(Salary)+MOE

mean(data$Salary)

#2.5% 

a=0.025

t= qt(p= a/2, df= DOF, lower.tail = F)

SE = sd(Salary)/sqrt(length(Salary))

MOE = t*SE

lower= mean(Salary)-MOE
upper= mean(Salary)+MOE

mean(data$Salary)

#1%

a=0.01

t= qt(p= a/2, df= DOF, lower.tail = F)

SE = sd(Salary)/sqrt(length(Salary))

MOE = t*SE

lower= mean(Salary)-MOE
upper= mean(Salary)+MOE

mean(data$Salary)


#####13.	Construct a 99%, 95%, and 90% confidence interval estimate for the pre and post variables

set.seed(51)
sample(data$Pre, 50, replace = T)

sample(data$Post, 50, replace = T)

Pre = sample(data$Pre, 50, replace = T)
Post = sample(data$Post, 50, replace = T)

#99%

a=0.01

t= qt(p= a/2, df= DOF, lower.tail = F)

#pre
SE = sd(Pre)/sqrt(length(Pre))

MOE = t*SE

lower= mean(Pre)-MOE
upper= mean(Pre)+MOE

mean(data$Pre)

#post

SE = sd(Post)/sqrt(length(Post))

MOE = t*SE

lower= mean(Post)-MOE
upper= mean(Post)+MOE

mean(data$Post)

#95%

a=0.05

t= qt(p= a/2, df= DOF, lower.tail = F)

#pre
SE = sd(Pre)/sqrt(length(Pre))

MOE = t*SE

lower= mean(Pre)-MOE
upper= mean(Pre)+MOE

mean(data$Pre)

#post

SE = sd(Post)/sqrt(length(Post))

MOE = t*SE

lower= mean(Post)-MOE
upper= mean(Post)+MOE

mean(data$Post)

##90%

a=0.1

t= qt(p= a/2, df= DOF, lower.tail = F)

#pre
SE = sd(Pre)/sqrt(length(Pre))

MOE = t*SE

lower= mean(Pre)-MOE
upper= mean(Pre)+MOE

mean(data$Pre)

#post

SE = sd(Post)/sqrt(length(Post))

MOE = t*SE

lower= mean(Post)-MOE
upper= mean(Post)+MOE

mean(data$Post)

##14.	Considering the Data.xlsx as a population:
###a.	Take a sample of 50 observations from the pre and post dataset (without replacement)


sample(data$Pre, 50, replace = F)

Pre = sample(data$Pre, 50, replace = F)

Post = sample(data$Post, 50, replace = F)

###b.	Construct a null hypothesis to examine whether the sample (50 observations) mean score of pre
##and post variables is significantly different from the population (1000 observations)
###c.	Compute corresponding Z values for pre and postvariables in the sample
install.packages("BSDA")
library(BSDA)

z.test(Pre,Post, alternative = "two.sided", conf.level = 0.95 , sigma.x = sd(data$Pre),
       sigma.y = sd(data$Post))

z.test(Pre,Post, alternative = "greater", conf.level = 0.95 , sigma.x = sd(data$Pre),
       sigma.y = sd(data$Post))

z.test(Pre,Post, alternative = "less", conf.level = 0.95 , sigma.x = sd(data$Pre),
       sigma.y = sd(data$Post))

###15.	Using the p-value method, determine whether the sample mean for the pre and post variables 
##differs significantly from the population mean at the 10% significance level

z.test(Pre,Post, alternative = "two.sided", conf.level = 0.90 , sigma.x = sd(data$Pre),
       sigma.y = sd(data$Post))

###16.	Calculate the critical Z value for the 10% level of significance and the decision rule 
##using the critical value approach

z.test(Pre,Post, alternative = "two.sided", conf.level = 0.90 , sigma.x = sd(data$Pre),
       sigma.y = sd(data$Post))

qnorm(p=0.1/2, lower.tail = T)

####17.	Compute the T-statistics value for the pre and post variables

t.test(Pre, Post, alternative = "two.sided", conf.level = 0.95)

t.test(Pre, Post, alternative = "greater", conf.level = 0.95)

t.test(Pre, Post, alternative = "less", conf.level = 0.95)


###18.	Calculate the p-value and the decision using the p-value approach for pre and post variables
##at a 10% level of significance

t.test(Pre, Post, alternative = "two.sided", conf.level = 0.90)


###19.	Calculate the critical T value for the level of significance of 10% and the decision rule
##using the critical value approach

t.test(Pre, Post, alternative = "two.sided", conf.level = 0.90)
 DOF = length(Pre)+ length(Post)-2
 qt(p=0.1/2, df= DOF, lower.tail = F) 
 