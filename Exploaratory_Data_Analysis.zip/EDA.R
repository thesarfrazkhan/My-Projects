setwd("C:/Users/User/Downloads/EDA/CEP")

##1.	Import the data files

application_record = read.csv("application_record.csv")
credit_record = read.csv("credit_record.csv")


####2.	Handling missing values and duplicates:
 ### 1.	Check for the missing values. Find a column-wise count of missing values

dim(application_record)

dim(credit_record)

summary(application_record)
summary(credit_record)

application_record$OCCUPATION_TYPE= as.factor(application_record$OCCUPATION_TYPE)
summary(application_record)

sum(is.na(application_record))
sum(is.na(credit_record))

###2.	Treat the columns with missing values with an appropriate strategy

application_record1 = data.frame(application_record [,c(1:16,18)])

sum(is.na(application_record1))

###3.	Check for duplicates in the ‘ID’ column and remove any

library(tidyverse)
application_record2 = distinct(application_record1,ID, .keep_all = T)

dim(application_record1)
dim(application_record2)

credit_record.1 = distinct(credit_record,ID, .keep_all = T)
dim(credit_record)
dim(credit_record.1)

####     3.Feature analysis:
###1.	What percentage of IDs are common between the two tables?

mergeddata= merge(application_record2,credit_record.1, by = 'ID')

percentage1= length(mergeddata$ID)/length(application_record2$ID)*100

percentage2 = length(mergeddata$ID)/length(credit_record.1$ID)*100

###2.	Visualize the distribution of income types

application_record2$NAME_INCOME_TYPE = as.factor(application_record2$NAME_INCOME_TYPE)

levels(application_record2$NAME_INCOME_TYPE)
barplot(table(application_record2$NAME_INCOME_TYPE), main = "Distribution of Income Types", 
        col = rainbow(5), xlab = "Income TYpe", ylab = "Frequency")

legend("topleft", c(levels(application_record2$NAME_INCOME_TYPE)), fill = rainbow(5), cex = 0.6)

###3.	Find the age in years and study the age distribution

application_record2$Age  = rowMeans(round(application_record2[11]/-365))

summary(application_record2$Age)
head(application_record2$Age)
hist(application_record2$Age, main= "Age Distribution", xlab= "Age", col = "blue", border = "red")

####4.	Study the gender distribution in applicants’ data

application_record2$CODE_GENDER = as.factor(application_record2$CODE_GENDER)

levels(application_record2$CODE_GENDER)
Gender_dist= table(application_record2$CODE_GENDER)

barplot(Gender_dist, main = "Gender Distribution in Applicants", col = c("blue", "red"), 
        xlab = "Gender")
legend("topright", c(levels(application_record2$CODE_GENDER)), fill = c("blue", "red"))


###5.	Study the average annual income across different education levels

application_record2|> group_by(NAME_EDUCATION_TYPE) |> summarise(mean(AMT_INCOME_TOTAL))

####6.	Find the count of applicants from different education levels.
##Also, showcase how many of those own a car.

application_record2|> count(NAME_EDUCATION_TYPE)

application_record2|> group_by(FLAG_OWN_CAR) |> count(NAME_EDUCATION_TYPE)

OwnCar= as.data.frame(application_record2|> group_by(FLAG_OWN_CAR) |> 
                        count(NAME_EDUCATION_TYPE))


install.packages("reshape2")
library(reshape2)

OwnCar.wide = dcast(OwnCar, FLAG_OWN_CAR ~ NAME_EDUCATION_TYPE, value.var = "n")

OwnCar.wide

###7.	Create a stacked column chart to visualize the above

barplot(as.matrix(OwnCar.wide[c(1,2), c(2:6)]), col = rainbow(5), border = "white",
        xlab = "Education Type", ylab = "Values")
legend("topleft", OwnCar.wide$FLAG_OWN_CAR, fill = rainbow(5))


####4.Feature creation:
##1.	Convert “STATUS” to a binary variable called ‘target’, where 0 is for good applicants 
##(where STATUS is either ‘C’, ‘X’ or ‘0’) and 1 is for bad applicants (where STATUS is either
##1,2,3,4,5)

Target = ifelse(credit_record.1$STATUS %in% c("C","X","0"), 0,1)


###2.	Merge the two datasets to get the common records

credit_record.2 = credit_record.1

credit_record.2$TARGET = Target

mergeddata2= merge(application_record2, credit_record.2, by = 'ID')

###3.	Study the data distribution in terms of the target

table(mergeddata2$TARGET)

barplot(table(mergeddata2$TARGET), names.arg = c("GOOD", "BAD"), col = rainbow(2), 
        horiz = T )
legend("topright", c("Good", "Bad"), fill = rainbow(2))

###5.Data preparation and modeling:
##1.	Convert categorical columns into factors

application_record2 = mutate(application_record2, across(where(is.character), as.factor))

credit_record.2 = mutate(credit_record.2, across(where(is.character), as.factor))

mergeddata2 = mutate(mergeddata2, across(where(is.character), as.factor))
mergeddata2$TARGET = as.factor(mergeddata2$TARGET)

#####2.	Use this cleaned data to build a classification model

install.packages("caret")
install.packages("randomForest")
install.packages("pROC")

library(caret)
library(randomForest)
library(pROC)


set.seed(1000)
 sample = createDataPartition(mergeddata2$TARGET, p=0.7, list = F)
train = mergeddata2[sample,] 

test = mergeddata2[-sample,] 

Model = randomForest(TARGET ~ ., data = train, ntree = 100)



####3.	Get predictions and evaluate the models using a confusion matrix and ROC curve.

prediction = predict(Model, test)

confusionMatrix(prediction, test$TARGET)

plot.roc(prediction, as.numeric(test$TARGET))


